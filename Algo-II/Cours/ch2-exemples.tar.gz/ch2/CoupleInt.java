public class CoupleInt
{
	
	public final int x, y;
	
	public CoupleInt(int x, int y) {
		this.x = x;
		this.y= y;
	}

}
