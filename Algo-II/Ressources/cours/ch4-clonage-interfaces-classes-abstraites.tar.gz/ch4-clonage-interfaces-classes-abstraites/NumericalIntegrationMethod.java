public interface NumericalIntegrationMethod
{

    double compute(double a, double width, Function f);

}
