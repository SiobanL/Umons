public interface Function
{

    double eval(double x);

}
