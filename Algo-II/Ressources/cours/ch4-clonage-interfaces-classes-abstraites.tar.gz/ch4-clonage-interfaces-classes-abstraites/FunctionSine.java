public class FunctionSine
implements Function
{

    public double eval(double x) {
	return Math.sin(x);
    }

}
