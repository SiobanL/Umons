public class HelloMain {
    public static void main(String args[]) {
        // On peut utiliser le nom d'une interface comme un type
        IHello[] tab = new IHello[2];
        // Une classe qui implemente une interface est aussi du type de cette
        // interface. Comme pour l'heritage.
        tab[0] = new HelloEnglish();
        tab[1] = new HelloFrench();
        for (IHello h: tab) {
            // Tout objet qui implemente une interface aura les methodes de
            // cette interface et elles doivent etre definies.
            h.hello();
        }
    }
}
