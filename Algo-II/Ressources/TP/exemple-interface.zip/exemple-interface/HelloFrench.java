// Pour "heriter" d'une interface, on utilise le mot-cle implements et pas
// extends.
public class HelloFrench implements IHello {
    // Une classe qui implemente une interface doit definir toutes les methodes
    // de cette interface
    public void hello() {
        System.out.println("Bonjour");
    }
}
