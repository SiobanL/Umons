// On utilise interface a la place de class pour definir une interface
public interface IHello {
    // Dans une interface, les methodes ne sont pas definies et on met juste un
    // ";"
    public void hello();
}
