// On utilise la notation <MonCompar> pour indiquer qu'on peut comparer avec
// des objets de type MonCompar. C'est une application des generiques.
public class MonCompar implements Comparable<MonCompar> {

    private int v;

    public MonCompar(int v) {
        this.v = v;
    }

    public int compareTo(MonCompar other) {
        // Retourne une valeur negative si other est plus grand, positive si
        // other est plus petit et 0 si les deux sont egaux
        return this.v - other.v;
    }
}
