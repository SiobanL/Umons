public class RobotRecursive extends Robot {
    // Profondeur maximale autorisée lors de l'exploration.
    protected int maxDepth;

    public RobotRecursive(Labyrinth lab, int maxDepth) {
        super(lab);
        this.maxDepth = maxDepth;
    }

    public int findExit() {
        // Pour chaque direction ..
        for(Labyrinth.Direction dir : this.directions) {
            // .. qui ne représente pas un mur, ni une case visitée (i.e. une
            // case du chemin que l'on est occupé de créer)
            if (!isWall(dir) && !isVisited(dir)) {
                // On explore dans cette direction avec une profondeur 0 car
                // on se trouve sur la case de départ pour le moment.
                int depth = explore(dir, 0);
                // Si on a trouvé une sortie, plus besoin de chercher dans les
                // autres direction, on peut retourner la profondeur.
                if(depth != -1){
                    return depth;
                }
            }
        }
        // Aucune des directions n'ont permis de trouver une sortie via la
        // case de départ.
        return -1;
    }

    /**
     * Explore le labyrinthe à la recherche de la sortie, en commençant par
     * aller dans la direction spécifiée par rapport à la position courante.
     *
     * @return la profondeur du chemin trouvé, -1 si aucun chemin existe pour
     *         la profondeur maximale spécifiée.
     */
    protected int explore(Labyrinth.Direction direction, int depth){
        // On se déplace dans la direction indiquée en paramètre.
        this.go(direction);
        // Cas de base 1 : si le déplacement crée un chemin trop long
        if(depth+1 > this.maxDepth){
            // on annule le dernier mouvement
            cancelMove();
            return -1;
        }
        // Cas de base 2 : On a trouvé une sortie
        else if(lab.isExit()){
            return depth+1;
        }
        // Cas général
        else{
            // Pour chaque direction ..
            for(Labyrinth.Direction dir : this.directions) {
                // .. qui ne représente pas un mur, ni une case visitée (i.e.
                // une case du chemin que l'on est occupé de créer)
                if (!isWall(dir) && !isVisited(dir)) {
                    // On explore dans cette direction avec en incrémentant
                    // la profondeur
                    int newDepth = explore(dir, depth+1);
                    // Si on a trouvé une sortie, plus besoin de chercher dans
                    // les autres direction, on peut retourner la profondeur.
                    if(newDepth != -1){
                        return newDepth;
                    }
                }
            }
            // Aucune direction n'a permis de trouver une sortie via la
            // position actuelle, on annule le dernier mouvement
            cancelMove();
            return -1;
        }
    }
    
    /**
     * Annule le dernier déplacement en revenant sur la case précédente et
     * en indiquant la case actuelle comme non-visitée.
     */
    protected void cancelMove(){
        // On "oublie" avoir visité la position actuelle en modifiant la grille
        visited.set(this.position, false);
        // On se déplace dans la direction opposée au dernier déplacement sur
        // base de notre orientation
        this.go(getOppositeDirection(this.orientation));
    }
    
    /**
     * Détermine la direction opposée à celle passée en paramètre.
     *
     * @param dir direction à inverser
     * @return la direction opposé à celle passée en paramètre
     */
    private Labyrinth.Direction getOppositeDirection(Labyrinth.Direction dir){
        switch(dir){
            case UP:
                return Labyrinth.Direction.DOWN;
            case DOWN:
                return Labyrinth.Direction.UP;
            case LEFT:
                return Labyrinth.Direction.RIGHT;
            case RIGHT:
                return Labyrinth.Direction.LEFT;
        }
        return Labyrinth.Direction.RIGHT;
    }
}
