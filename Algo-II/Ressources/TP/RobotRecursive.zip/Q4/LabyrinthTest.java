public class LabyrinthTest
{
    public static void main(String[] args)
    {
        Labyrinth lab = Labyrinth.laby1();
        Robot robot = new RobotRecursive(lab,20);
        int pas = robot.findExit();
        System.out.println("Nombre de pas: "+pas);
    }
}

