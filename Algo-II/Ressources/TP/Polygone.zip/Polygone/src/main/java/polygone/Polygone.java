package polygone;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Button;
import javafx.geometry.Pos;

public class Polygone extends Application {

    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage stage) {
        stage.setTitle("Polygone");

        BorderPane root = new BorderPane();
        Canvas canvas = new Canvas(WIDTH, HEIGHT);
        root.setCenter(canvas);

        HBox inputs = new HBox();
        inputs.getChildren().add(new Label("Nombre de cotes :"));
        TextField number = new TextField();
        inputs.getChildren().add(number);
        Button draw = new Button("DRAW");
        inputs.getChildren().add(draw);
        CheckBox drawCircle = new CheckBox("Dessiner le cercle");
        inputs.getChildren().add(drawCircle);
        draw.setOnAction(evt -> drawPolygon(number.getText(), canvas.getGraphicsContext2D(), canvas.getWidth(), canvas.getHeight(), drawCircle.isSelected()));

        inputs.setAlignment(Pos.CENTER);
        root.setTop(inputs);

        Scene scene = new Scene(root);
        stage.setScene(scene);

        stage.show();
    }

    public void drawPolygon(String text, GraphicsContext gc, double width, double height, boolean circle) {
        try {
            double n = Double.parseDouble(text);
            gc.clearRect(0, 0, width, height);
            double maxDim = Math.min(width, height) / 2;
            double angle = 2 * Math.PI / n;
            double cx = width / 2.;
            double cy = height / 2.;
            for (int i = 0; i < n; ++i) {
                gc.strokeLine(cx + maxDim*Math.cos(i*angle),
                        cy + maxDim*Math.sin(i*angle),
                        cx + maxDim*Math.cos((i+1)*angle),
                        cy + maxDim*Math.sin((i+1)*angle));
            }
            if (circle) {
                gc.strokeOval(cx-maxDim, cy-maxDim, 2*maxDim, 2*maxDim);
            }
        } catch (NumberFormatException e) {

        }
    }

}
