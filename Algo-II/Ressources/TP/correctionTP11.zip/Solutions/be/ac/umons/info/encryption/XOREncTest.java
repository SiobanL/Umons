package be.ac.umons.info.encryption;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.FilterOutputStream;

public class XOREncTest {

    public static void main(String[] args) throws IOException {
        if (args.length != 1 || args[0].length() == 0) {
            System.out.println("usage: XOREncTest <KEY>");
            System.exit(1);
        }

        //byte base = args[0].getBytes()[0];
        byte[] base = args[0].getBytes();
        FilterOutputStream output = new FilterOutputStream(System.out) {
            @Override
            public void write( int b ) throws IOException {
                ((PrintStream) out).print(" " + b + " ");
            }
        };

        XOREncoding.encode(System.in, output, base);
        System.out.flush();
    }
}
