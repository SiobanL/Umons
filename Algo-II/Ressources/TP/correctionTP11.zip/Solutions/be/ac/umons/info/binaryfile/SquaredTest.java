package be.ac.umons.info.binaryfile;

import java.io.File;
import java.io.FileInputStream;
import java.io.RandomAccessFile;
import java.io.IOException;
import java.io.FileNotFoundException;

public class SquaredTest{

    public static void main(String[] args){
        if(args.length != 2){
            System.out.println("usage: SquaredTest INPUT_FILE INTEGER");
            System.exit(1);
        }

        File inputFile = new File(args[0]);
        int n = 0;
        try{
            n = Integer.parseInt(args[1]);
        }
        catch(NumberFormatException e){
            System.out.println("usage: SquaredTest INPUT_FILE INTEGER");
            System.exit(1);
        }

        try (
            RandomAccessFile raf = new RandomAccessFile(inputFile, "r");
        )
        {
            raf.seek(n*4);
            int square = raf.readInt();
            System.out.println(square);
        }
        catch(FileNotFoundException e){
            System.out.println("Input file does not exist !");
        }
        catch(IOException e){
            System.out.println("Error while reading input file");
        }
    }
}
