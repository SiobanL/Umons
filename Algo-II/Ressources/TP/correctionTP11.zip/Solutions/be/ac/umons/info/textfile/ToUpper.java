package be.ac.umons.info.textfile;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.FileNotFoundException;


public class ToUpper{
    public static void main(String[] args){
        if(args.length != 2){
            System.out.println("usage: ToUpper INPUT_FILE OUTPUT_FILE");
            System.exit(1);
        }

        File inputFile = new File(args[0]);
        File outputFile = new File(args[1]);

        nestedTry(inputFile, outputFile);
        //tryWithResources(inputFile, outputFile);
    }

    /* 
    Version utilisant des blocs "try" imbriqués.
    */
    public static void nestedTry(File inputFile, File outputFile){
        try{
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            try{
                BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile));
                try{
                    String line;
                    while((line = br.readLine()) != null){
                        bw.write(line.toUpperCase());
                        bw.newLine();
                    }
                }
                finally{
                    bw.close();
                }
            }
            catch(IOException e){
                System.out.println("Error while reading/writing input/output file"+e.getMessage());
            }
            finally{
                try{
                    br.close();
                }
                catch(IOException e){
                    System.out.println("Could not close file");
                }
            }
        }
        catch(FileNotFoundException e){
            System.out.println("Input file does not exist !");
        }
    }
    
    /* 
    Version utilisant try-with-resources.
    */
    public static void tryWithResources(File inputFile, File outputFile){
        try (
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            BufferedWriter bw = new BufferedWriter(new FileWriter(outputFile))
        ) {
            String line;
            while((line = br.readLine()) != null){
                bw.write(line.toUpperCase());
                bw.newLine();
            }
        }
        catch(FileNotFoundException e){
            System.out.println("Input file does not exist !");
        }
        catch(IOException e){
            System.out.println("Error while reading/writing input/output file"+e.getMessage());
        }
    }
}
