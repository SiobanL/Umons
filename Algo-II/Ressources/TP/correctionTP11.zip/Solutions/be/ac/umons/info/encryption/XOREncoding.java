package be.ac.umons.info.encryption;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;

public class XOREncoding{
    public static void encode(InputStream is, OutputStream os, byte base)
            throws IOException{
        int b;
        while((b = is.read()) != -1){
            os.write(b ^ base);
        }
    }

    public static void encode(InputStream is, OutputStream os, byte[] key)
            throws IOException{
        int b;
        int i = 0;
        int length = key.length;
        while((b = is.read()) != -1){
            os.write(b ^ key[i%length]);
            i++;
        }
    }
}
