package be.ac.umons.info.binaryfile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

public class Squared{
    public static void main(String[] args){
        if(args.length != 1){
            System.out.println("usage: Squared OUTPUT_FILE");
            System.exit(1);
        }

        File outputFile = new File(args[0]);

        try (
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(outputFile));
            DataOutputStream dos = new DataOutputStream(bos);
        )
        {
            for(int i=0;i<1000;i++){
                int square = i*i;
                dos.writeInt(square);
            }
        }
        catch(IOException e){
            System.out.println("Error while writing in output file");
        }
    }

}
