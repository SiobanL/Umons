package be.ac.umons.info.textfile;

import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Arrays;

public class FrequencyAnalyser{

    public static void main(String[] args){
        if(args.length != 1){
            System.out.println("usage: FrequencyAnalyser INPUT_FILE");
            System.exit(1);
        }

        File inputFile = new File(args[0]);

        try (
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
        )
        {
            processASCIIFile(br);
        }
        catch(FileNotFoundException e){
            System.out.println("Input file does not exist !");
        }
        catch(IOException e){
            System.out.println("Error while reading file.");
        }
    }

    private static void processASCIIFile(BufferedReader br) throws IOException{
        HashMap<Character,Integer> lettersCount =
            new HashMap<Character,Integer>();

        // Contiendra la position dans l'encodage ASCII de la lettre lue
        int character;
        double number = 0;
        while((character = br.read()) != -1){
            // Si le charactère est entre A et Z.
            // 'A' ayant la valeur 65 et 'Z' ayant la valeur 90.
            if(character >= 65 && character <= 90){
               // On transforme la majuscule en minuscule pour gérer ce
               // cas dans le bloc "if" qui suit.
               character += 32;
            }
            if(character >= 97 && character <= 122){
                Character c = Character.valueOf((char)character);
                int v = lettersCount.getOrDefault(c,0);
                lettersCount.put(c,v+1);
                number++;
            }
        }

        Character[] keys = lettersCount.keySet().toArray(new Character[0]);

        Arrays.sort(keys,
                    (char1,char2) ->
                        lettersCount.get(char2).compareTo(
                            lettersCount.get(char1)));

        for(Character key: keys){
            System.out.println(key+": "+lettersCount.get(key)/number*100);
        }
    }
}
