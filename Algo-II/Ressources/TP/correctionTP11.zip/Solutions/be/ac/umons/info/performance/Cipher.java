package be.ac.umons.info.performance;

import java.io.File;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.io.FileNotFoundException;

import be.ac.umons.info.encryption.XOREncoding;

public class Cipher{

    public static void usage(){
        System.out.println(
                "usage: Cipher INPUT_FILE OUTPUT_FILE KEY IBS OBS");
        System.exit(1);
    }

    public static void main(String[] args){
        if(args.length < 3){
            usage();
        }

        File inputFile = new File(args[0]);
        File outputFile = new File(args[1]);
        byte[] key = args[2].getBytes();

        // Output block size (taille du buffer de lecture)
        int ibs = -1;
        // Input block size (taille du buffer d'écriture)
        int obs = -1;

        CpuTime time = new CpuTime();

        try{
            if(args.length >= 4)
                ibs = Integer.parseInt(args[3]);
            if(args.length == 5)
                obs = Integer.parseInt(args[4]);
        }
        catch(NumberFormatException e){
            usage();
        }

        try (
            InputStream is = new FileInputStream(inputFile);
            OutputStream os = new FileOutputStream(outputFile);
        ){
            InputStream fis = is;
            OutputStream fos = os;
            if(ibs < 0){
                fis = new BufferedInputStream(is);
            }
            else if(ibs > 0){
                fis = new BufferedInputStream(is,ibs);
            }

            if(obs < 0){
                fos = new BufferedOutputStream(os);
            }
            else if(obs > 0){
                fos = new BufferedOutputStream(os,obs);
            }

            time.start();
            if(key.length > 1)
                XOREncoding.encode(fis,fos,key);
            else
                XOREncoding.encode(fis,fos,key[0]);
            time.stop();
            System.out.println(time.getTime());
        }
        catch(FileNotFoundException e){
            System.out.println("Input file does not exist !");
        }
        catch(IOException e){
            System.out.println(
                    "Error while reading/writing input/output file"
                    + e.getMessage());
        }
    }
}
