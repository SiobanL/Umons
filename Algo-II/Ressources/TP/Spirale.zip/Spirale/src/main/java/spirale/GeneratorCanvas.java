package spirale;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.geometry.Point2D;

import java.util.ArrayList;

public class GeneratorCanvas extends Canvas{
    private Point2D previousPoint;
    private int dir;
    private Generator gen;

    private static final Point2D[] DIRS = {
        new Point2D(0, -1),
        new Point2D(-1, 0),
        new Point2D(0, 1),
        new Point2D(1, 0)
    };
    private static final double INCREMENT = 10;

    public GeneratorCanvas(double width, double height, Generator gen) {
        super(width, height);
        setGenerator(gen);
    }

    public void setGenerator(Generator gen) {
        double width = getWidth();
        double height = getHeight();
        this.gen = gen;
        this.previousPoint = new Point2D(width/2, height/2);
        this.dir = 0;
        GraphicsContext gc = getGraphicsContext2D();
        gc.setStroke(Color.BLUE);
        gc.clearRect(0, 0, width, height);
    }

    public void next() {
        int nextVal = this.gen.next();
        Point2D nextPoint = this.previousPoint.add(DIRS[dir].multiply(nextVal).multiply(INCREMENT));
        dir = (dir + 1) % DIRS.length;
        GraphicsContext gc = getGraphicsContext2D();
        gc.strokeLine(this.previousPoint.getX(), this.previousPoint.getY(), nextPoint.getX(), nextPoint.getY());
        this.previousPoint = nextPoint;
    }
}
