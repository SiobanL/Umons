package spirale;

public interface Generator {
    public int next();
}
