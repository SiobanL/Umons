package spirale;

public class Fibonacci implements Generator {
    private int n1, n2;

    public Fibonacci() {
        this.n2 = 0;
        this.n1 = 1;
    }

    public int next() {
        int res = this.n2;
        this.n2 = this.n1;
        this.n1 = res + this.n1;
        return res;
    }
}
