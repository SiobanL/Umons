package spirale;

public class PlusUn implements Generator {
    private int previous;

    public PlusUn() {
        this.previous = 0;
    }

    public int next() {
        return this.previous++;
    }
}
