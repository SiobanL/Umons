public class RobotRightHand extends Robot {

    public RobotRightHand(Labyrinth lab) {
        super(lab);
    }

    public int findExit() {
        // On cherche le premier mur en se déplaçant à droite
        this.findAWall();
        // Une fois à côté du mur, on s'oriente vers le nord
        this.orientation = Labyrinth.Direction.UP;
        while (!lab.isExit()) {
            lab.print();
            Labyrinth.Direction dir = getNextDirection();
            if(!isVisited(dir))
                go(dir);
            else
                return -1;
        }
        return this.steps;
    }

    /**
     * Se déplace vers le premier mur sur la droite.
     */
    public void findAWall(){
        while(!isWall(Labyrinth.Direction.RIGHT)){
            // On se déplace à droite
            go(Labyrinth.Direction.RIGHT);
            if(lab.isExit()){
                break;
            }
        }
    }

    /**
     * Retourne le prochain déplacement en fonction de notre position actuelle
     * et de notre orientation de telle sorte à toujours avoir un mur sur
     * sa droite.
     *
     * @return la prochaine direction dans laquelle se déplacer.
     */
    public Labyrinth.Direction getNextDirection(){
        if(!isHandTouchingWall()){
            return getDirectionOnRight();
        }
        else if(!isWall(this.orientation)){
            return this.orientation;
        }
        else{
            return getDirectionOnLeft();
        }
    }
    
    private boolean isHandTouchingWall(){
        switch(this.orientation){
            case UP:
                return lab.isWall(Labyrinth.Direction.RIGHT);
            case DOWN:
                return lab.isWall(Labyrinth.Direction.LEFT);
            case LEFT:
                return lab.isWall(Labyrinth.Direction.UP);
            case RIGHT:
                return lab.isWall(Labyrinth.Direction.DOWN);
        }
        return false;
    }

    private Labyrinth.Direction getDirectionOnRight(){
        switch(this.orientation){
            case UP:
                return Labyrinth.Direction.RIGHT;
            case DOWN:
                return Labyrinth.Direction.LEFT;
            case LEFT:
                return Labyrinth.Direction.UP;
            case RIGHT:
                return Labyrinth.Direction.DOWN;
        }
        return Labyrinth.Direction.RIGHT;
    }
    
    private Labyrinth.Direction getDirectionOnLeft(){
        switch(this.orientation){
            case UP:
                return Labyrinth.Direction.LEFT;
            case DOWN:
                return Labyrinth.Direction.RIGHT;
            case LEFT:
                return Labyrinth.Direction.DOWN;
            case RIGHT:
                return Labyrinth.Direction.UP;
        }
        return Labyrinth.Direction.RIGHT;
    }
}
