public class LabyrinthTest
{
    public static void main(String[] args)
    {
        Labyrinth lab = Labyrinth.laby1();
        Robot robot = new RobotRightHand(lab);
        int pas = robot.findExit();
        System.out.println("Nombre de pas: "+pas);
    }
}

