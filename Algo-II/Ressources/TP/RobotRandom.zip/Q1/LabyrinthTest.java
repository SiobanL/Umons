public class LabyrinthTest
{
    public static void main(String[] args)
    {
        Labyrinth lab = Labyrinth.laby1();
        Robot robot = new RobotRandom(lab);
        robot.findExit();
    }
}

