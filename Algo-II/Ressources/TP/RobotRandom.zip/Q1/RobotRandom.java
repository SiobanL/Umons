import java.util.Random;

public class RobotRandom extends Robot
{
    // Générateur de Nombre
    private Random rnd;

    public RobotRandom(Labyrinth lab)
    {
        // On appelle le constructeur de la classe parent 'Robot'
        super(lab);
        // on initialise le générateur de nombres
        rnd = new Random();
    }

    public int findExit()
    {
        // Tableau vide qui contiendra (au plus) 4 directions
        Labyrinth.Direction[] valid_dirs = new Labyrinth.Direction[4];
        // Tant que le robot n'a pas trouvé la sortie
        while (!lab.isExit())
        {
            // remplit le tableau 'valid_dirs' des déplacements autorisées
            // retourne le nombre de directions insérées dans le tableau
            int n = getValidDirections(valid_dirs);
            // On récupère une direction au hasard dans ce tableau
            Labyrinth.Direction dir = valid_dirs[rnd.nextInt(n)];
            System.out.println(dir);
            // On se déplace dans la direction choisie au hasard (qui est
            // valide)
            go(dir);
            // On affiche l'état actuel du labyrinthe
            lab.print();
        }
        return this.steps;
    }
}
