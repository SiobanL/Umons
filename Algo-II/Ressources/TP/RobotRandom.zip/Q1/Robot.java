public class Robot
{
    // Référence vers le labyrinthe duquel il faut sortir
    protected Labyrinth lab;
    // Nombre de pas/déplacements effectués par le robot
    protected int steps;
    // Représente l'ensemble des déplacements valides. Commun a l'ensemble des
    // instances donc variable associée à la classe (i.e. 'static')
    private static Labyrinth.Direction[] directions = {
        Labyrinth.Direction.UP, Labyrinth.Direction.RIGHT,
        Labyrinth.Direction.DOWN, Labyrinth.Direction.LEFT
    };

    /**
     * Constructeur de 'Robot'
     *
     * @param lab   le labyrinthe dont il faut trouver une sortie
     */
    public Robot(Labyrinth lab) {
        this.lab = lab;
        this.steps = 0;
    }

    /**
     * Trouve la sortie du labyrinthe
     *
     * @return le nombre de pas effectués pour trouver la sortie, '-1' si aucune
     *         sortie n'a été trouvée.
     */
    public int findExit() {
        return -1;
    }

    /**
     * Remplit (par effet de bord) le tableau passé en paramètre
     * des directions valides/autorisées depuis la position actuelle.
     * 
     * @param tab   tableau (de taille 4) dans lequel les directions seront
                    insérés
     * @return le nombre de directions insérées dans le tableau
     */
    protected int getValidDirections(Labyrinth.Direction[] tab) {
        int n = 0;
        for(Labyrinth.Direction dir : directions) {
            if (!lab.isWall(dir)) {
                tab[n] = dir;
                n++;
            }
        }
        return n;
    }
    
    /**
     * Déplace le robot dans la direction passée en paramètre; Retourne vrai 
     * si le déplacement depuis la position actuelle vers la direction passée 
     * en paramètre s'est fait avec succès; Enregistre également la nouvelle 
     * position comme étant visitée dans la grille "mémoire".
     *
     * @param dir   la direction dans laquelle on veut se déplacer.
     * @return vrai si le déplacement s'est fait avec succès,
               faux sinon.
     */
    public boolean go(Labyrinth.Direction dir) {
        if(!lab.isWall(dir)) {
            lab.go(dir);
            this.steps++;
            return true;
        }
        else {
            return false;
        }
    }
}
