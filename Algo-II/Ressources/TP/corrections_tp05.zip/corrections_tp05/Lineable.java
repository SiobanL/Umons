public interface Lineable
{
    public boolean canPass();
}
