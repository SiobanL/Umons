public abstract class Vehicle implements Lineable
{
    protected String brand;

    public Vehicle(String brand)
    {
        this.brand = brand;
    }
}
