public class MyArrayListTest
{
    public static void testList(MyArrayList<Integer> l)
    {
        for (int i = 0; i < 10000; ++i)
        {
            l.add(0);
            System.out.println(
                    l.size() + " " + l.getV() + " " + l.getW() +
                    " " + l.getX() + " " + l.getY());
        }
        System.out.println("\n");
    }

    public static void main(String[] args)
    {
        MyArrayList<Integer> l = new AdditiveArrayList<Integer>(1,2);
        testList(l);
        l = new AdditiveArrayList<Integer>(10,2);
        testList(l);
        l = new AdditiveArrayList<Integer>(100,2);
        testList(l);
        l = new AdditiveArrayList<Integer>(10,100);
        testList(l);
        l = new AdditiveArrayList<Integer>(100,100);
        testList(l);
        l = new MultiplicativeArrayList<Integer>(2,1);
        testList(l);
        l = new MultiplicativeArrayList<Integer>(3,1);
        testList(l);
        l = new MultiplicativeArrayList<Integer>(5,1);
        testList(l);
        l = new MultiplicativeArrayList<Integer>(10,1);
        testList(l);
        l = new MultiplicativeArrayList<Integer>(5,100);
        testList(l);
    }
}
