import java.util.Random;
import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListTest
{
    public static ArrayList<String> create(int n)
    {
        Random rnd = new Random();
        ArrayList<String> list = new ArrayList<>();
        for (int i = 0; i < n; ++i)
        {
            String str = "";
            int k = rnd.nextInt(101);
            for (int j = 0; j < k; ++j)
            {
                str += (char) (rnd.nextInt(95 /*126 - 32 + 1 */) + 32);
            }
            list.add(str);
        }
        return list;
    }

    public static void add(ArrayList<String> l, String s)
    {
        l.add(s);
    }

    public static void empty(ArrayList<String> l)
    {
        l.clear();
    }

    public static void displaySimple(ArrayList<String> l)
    {
        System.out.println("[");
        for (String str : l)
        {
            System.out.println(str);
        }
        System.out.println("]");
    }

    public static void display(ArrayList<String> l)
    {
        System.out.print("[");
        for (Iterator<String> i = l.iterator(); i.hasNext();)
        {
            System.out.print(i.next());
            if (i.hasNext())
                System.out.print("\n ");
        }
        System.out.println("]");
    }

    public static void main(String args[])
    {
        ArrayList<String> list = create(3);
        display(list);
        add(list, "Hello World !");
        display(list);
        empty(list);
        add(list, "Prog algo 2");
        display(list);
        add(list, "Hello !");
        display(list);
    }
}
