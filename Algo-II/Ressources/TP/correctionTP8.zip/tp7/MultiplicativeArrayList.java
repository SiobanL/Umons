public class MultiplicativeArrayList<T> extends MyArrayList<T>
{
    public MultiplicativeArrayList(int x, int n)
    {
        super(x, n);
    }

    protected int increasedPhysicalSize()
    {
        return physicalSize() * x;
    }
}
