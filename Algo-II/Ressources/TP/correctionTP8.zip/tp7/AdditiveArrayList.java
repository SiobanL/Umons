public class AdditiveArrayList<T> extends MyArrayList<T>
{
    public AdditiveArrayList(int x, int n)
    {
        super(x, n);
    }

    protected int increasedPhysicalSize()
    {
        return this.physicalSize() + x;
    }
}
