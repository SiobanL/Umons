public abstract class MyArrayList<T>
{
    protected Object[] array;
    protected int size = 0;
    protected int x;

    /* Calcul des stats. */
    protected int nCopyCumul = 0;
    protected int sumEffectUtil = 0;

    public MyArrayList(int x, int n)
    {
        this.x = x;
        array = new Object[n];
    }

    public int size()
    {
        return size;
    }

    public int physicalSize()
    {
        return array.length;
    }

    protected boolean isValidIndex(int i)
    {
        return i >= 0 && i < size();
    }

    public T get(int i)
    {
        if (!isValidIndex(i))
            throw new ArrayIndexOutOfBoundsException();
        /* Syntaxe un peu spéciale car on veut retourner un type T à partir
         * d'un Object interne et qu'on veut supprimer le warning car "on sait
         * ce qu'on fait". */
        @SuppressWarnings("unchecked")
        final T o = (T) array[i];
        return o;
    }

    protected abstract int increasedPhysicalSize();

    protected void reallocate()
    {
        Object[] newArray = new Object[increasedPhysicalSize()];
        if (size > 0)
        {
            System.arraycopy(array, 0, newArray, 0, size());
            /* Calcul des stats. */
            nCopyCumul += size();
        }
        array = newArray;
    }

    public void add(T o)
    {
        if (size() >= physicalSize())
            reallocate();

        array[size()] = o;
        size++;

        /* Calcul des stats. */
        sumEffectUtil += getX();
    }

    public void add(int i, T o)
    {
        if (isValidIndex(i))
        {
            if (size() >= physicalSize())
                reallocate();
            for (int j = size; j > i; --j)
            {
                array[j] = array[j-1];
            }
            array[i] = o;
            size++;

            /* Calcul des stats. */
            sumEffectUtil += getX();
        }
        else
        {
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    public int getV()
    {
         return physicalSize();
    }

    public int getW()
    {
        return nCopyCumul;
    }

    public float getX()
    {
         return size() / (float) physicalSize();
    }

    public float getY()
    {
        return sumEffectUtil / (float) size();
    }
}
