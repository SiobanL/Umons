""" Devrait afficher dans la console:
11/10
617/500
1/2
17/8
1
"""

from rational import Rational

print(Rational(1.1))
print(Rational(1.234))
print(Rational(0.5))
print(Rational(2.125))
print(Rational(1.0))
