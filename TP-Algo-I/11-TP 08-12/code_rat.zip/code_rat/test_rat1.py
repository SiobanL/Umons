""" Devrait afficher dans la console:
1/2
2/4
2/1
3/0
"""

from rational import Rational

print(Rational(1, 2))
print(Rational(2, 4))
print(Rational(2, 1))
print(Rational(3, 0))

