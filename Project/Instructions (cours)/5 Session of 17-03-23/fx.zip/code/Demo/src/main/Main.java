/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import javafx.application.Application;
import ui.App1_Hello;

/**
 *
 * @author serra
 */
public class Main
{
    public static void main(String[] args) 
    {
        Application.launch(App1_Hello.class, args);
        //Application.launch(App2_Components.class, args);
        //Application.launch(App3_Handler.class, args);
        //Application.launch(App4_Handler_Detail.class, args);
    }
    
}
