        //--- Button Events Handling
        InsertButtonHandler insertCtrl = new InsertButtonHandler(txaMsg,tfdCharacter);
        btnInsert.addEventHandler(ActionEvent.ACTION, insertCtrl);
