class Point:
    """ represente un point dans le plan """
    def __init__(self, x, y):
        self.x = x
        self.y = y