from rational import *

p = Rational(1, 3)
q = Rational(2, 4)
r = Rational(0.1)

print("p =", p, "; q =", q, "; r =", r)
print("p + q = ", p + q)
print("2 * r = ", 2 * r)
